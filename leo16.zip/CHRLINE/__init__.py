from .client import CHRLINE

# ORIGINAL LICENSE
__copyright__       = 'Copyright 2020-2021 by DeachSword'
__version__         = '1.3.5'
__license__         = 'BSD-3-Clause'
__author__          = 'DeachSword - YinMo'
__url__             = 'http://github.com/DeachSword'

__all__ = ['CHRLINE']